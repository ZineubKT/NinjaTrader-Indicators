using System;
using System.ComponentModel;
using System.Xml.Serialization;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;

// Mode enum at top
public enum CandleTicksMode
{
    Simple,
    Advanced
}

namespace NinjaTrader.NinjaScript.Indicators
{
    public class CandleTicksPro : Indicator
    {
        [NinjaScriptProperty]
        [DisplayName("Indicator Mode")]
        public CandleTicksMode Mode { get; set; }

        [NinjaScriptProperty]
        [DisplayName("Vertical Offset (in ticks)")]
        public int OffsetTicks { get; set; }

        [XmlIgnore]
        public Brush LowerWickColor { get; set; }

        [XmlIgnore]
        public Brush BodyColor { get; set; }

        [XmlIgnore]
        public Brush UpperWickColor { get; set; }

        [Browsable(false)]
        public string LowerWickColorSerializable
        {
            get { return Serialize.BrushToString(LowerWickColor); }
            set { LowerWickColor = Serialize.StringToBrush(value); }
        }

        [Browsable(false)]
        public string BodyColorSerializable
        {
            get { return Serialize.BrushToString(BodyColor); }
            set { BodyColor = Serialize.StringToBrush(value); }
        }

        [Browsable(false)]
        public string UpperWickColorSerializable
        {
            get { return Serialize.BrushToString(UpperWickColor); }
            set { UpperWickColor = Serialize.StringToBrush(value); }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "CandleTicks Pro";
                Description = "Shows either total candle ticks (simple) or separate counts for lower wick, body, and upper wick (advanced).";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = false;

                Mode = CandleTicksMode.Simple;
                OffsetTicks = 2;

                LowerWickColor = Brushes.White;
                BodyColor = Brushes.Cyan;
                UpperWickColor = Brushes.Yellow;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 1)
                return;

            double tickSize = Instrument.MasterInstrument.TickSize;
            double openPrice = Open[0];
            double closePrice = Close[0];
            double highPrice = High[0];
            double lowPrice = Low[0];

            if (Mode == CandleTicksMode.Simple)
            {
                // Simple mode: total candle range in ticks
                int totalTicks = (int)Math.Round((highPrice - lowPrice) / tickSize, 0, MidpointRounding.AwayFromZero);
                Draw.Text(this, "simple_" + CurrentBar, totalTicks.ToString(), 0, highPrice + OffsetTicks * tickSize, BodyColor);
            }
            else if (Mode == CandleTicksMode.Advanced)
            {
                // Advanced mode: separate counts
                int lowerWickTicks = (int)Math.Round((Math.Min(openPrice, closePrice) - lowPrice) / tickSize, 0, MidpointRounding.AwayFromZero);
                if (lowerWickTicks < 0) lowerWickTicks = 0;

                int bodyTicks = (int)Math.Round(Math.Abs(openPrice - closePrice) / tickSize, 0, MidpointRounding.AwayFromZero);
                if (bodyTicks < 0) bodyTicks = 0;

                int upperWickTicks = (int)Math.Round((highPrice - Math.Max(openPrice, closePrice)) / tickSize, 0, MidpointRounding.AwayFromZero);
                if (upperWickTicks < 0) upperWickTicks = 0;

                // Draw lower wick ticks
                Draw.Text(this, "lw_" + CurrentBar, lowerWickTicks.ToString(), 0, lowPrice - OffsetTicks * tickSize, LowerWickColor);

                // Draw body ticks at candle body center
                double bodyCenter = (openPrice + closePrice) / 2;
                Draw.Text(this, "body_" + CurrentBar, bodyTicks.ToString(), 0, bodyCenter, BodyColor);

                // Draw upper wick ticks
                Draw.Text(this, "uw_" + CurrentBar, upperWickTicks.ToString(), 0, highPrice + OffsetTicks * tickSize, UpperWickColor);
            }
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CandleTicksPro[] cacheCandleTicksPro;
		public CandleTicksPro CandleTicksPro(CandleTicksMode mode, int offsetTicks)
		{
			return CandleTicksPro(Input, mode, offsetTicks);
		}

		public CandleTicksPro CandleTicksPro(ISeries<double> input, CandleTicksMode mode, int offsetTicks)
		{
			if (cacheCandleTicksPro != null)
				for (int idx = 0; idx < cacheCandleTicksPro.Length; idx++)
					if (cacheCandleTicksPro[idx] != null && cacheCandleTicksPro[idx].Mode == mode && cacheCandleTicksPro[idx].OffsetTicks == offsetTicks && cacheCandleTicksPro[idx].EqualsInput(input))
						return cacheCandleTicksPro[idx];
			return CacheIndicator<CandleTicksPro>(new CandleTicksPro(){ Mode = mode, OffsetTicks = offsetTicks }, input, ref cacheCandleTicksPro);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CandleTicksPro CandleTicksPro(CandleTicksMode mode, int offsetTicks)
		{
			return indicator.CandleTicksPro(Input, mode, offsetTicks);
		}

		public Indicators.CandleTicksPro CandleTicksPro(ISeries<double> input , CandleTicksMode mode, int offsetTicks)
		{
			return indicator.CandleTicksPro(input, mode, offsetTicks);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CandleTicksPro CandleTicksPro(CandleTicksMode mode, int offsetTicks)
		{
			return indicator.CandleTicksPro(Input, mode, offsetTicks);
		}

		public Indicators.CandleTicksPro CandleTicksPro(ISeries<double> input , CandleTicksMode mode, int offsetTicks)
		{
			return indicator.CandleTicksPro(input, mode, offsetTicks);
		}
	}
}

#endregion
